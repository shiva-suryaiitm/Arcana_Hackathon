from django.shortcuts import render
from django.http import JsonResponse
import matplotlib.pyplot as plt


def test(request):
  return render(request,"base.html")

def test2(request):
  return render(request,"index2.html")

def plot(request):

  symbol = request.POST["sym"]
  img_path = []
  if(symbol == "AFL"):
    img_path.append("./static/img/AFLprice.png")
    img_path.append("./static/img/AFLvolume.png")

  elif(symbol == "FACO"):
    img_path.append("./static/img/FACOprice.png")
    img_path.append("./static/img/FACOvolume.png")

  elif(symbol == "FICO"):
    img_path.append("./static/img/FICOprice.png")
    img_path.append("./static/img/FICOvolume.png")

  elif(symbol == "WDC"):
    img_path.append("./static/img/WDCprice.png")
    img_path.append("./static/img/WDCvolume.png")

  elif(symbol == "MOG-A"):
    img_path.append("./static/img/MOG-Aprice.png")
    img_path.append("./static/img/MOG-Avolume.png")

  return render(request, 'result.html', {'img_path': img_path})