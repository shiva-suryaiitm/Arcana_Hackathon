import matplotlib.pyplot as plt
import os

def draw(shape):
    # create the figure and axis objects
    fig, ax = plt.subplots()
    # img_path = "static/img/"
    # if not os.path.exists(img_path):
    #      os.makedirs(img_path)

    # draw the shape
    if shape == 'triangle':
        ax.plot([0, 1, 0], [0, 1, 1], 'r-', lw=2)
    elif shape == 'square':
        ax.plot([0, 1, 1, 0, 0], [0, 0, 1, 1, 0], 'b-', lw=2)
    elif shape == 'circle':
        circle1 = plt.Circle((0.5, 0.5), 0.3, color='g', fill=False, lw=2)
        ax.add_artist(circle1)
    
    # set the axis limits and labels
    ax.set_xlim([-0.1, 1.1])
    ax.set_ylim([-0.1, 1.1])
    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.set_title('Shape: {}'.format(shape))
    
    # save the image file
    img_path = "./static/img/" + f"{shape}"
    plt.savefig(img_path)
    # close the figure
    plt.close(fig)
    
    # return the file path
    return img_path

draw("circle")