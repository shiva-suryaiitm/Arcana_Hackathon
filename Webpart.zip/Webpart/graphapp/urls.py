from django.urls import path,include
from . import views
urlpatterns = [
    path('', views.test, name='test'),
    path('index2.html', views.test2, name='test'),
    path('plot',views.plot,name = 'plot')
]
