import pandas as pd
import numpy as np
import glob
import json
import os


import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from datetime import datetime

# for date and time
from datetime import datetime 
from tqdm import tqdm
# graphs


# sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import MinMaxScaler, StandardScaler, OneHotEncoder

import torch
import torch.nn as nn

# torch dataloaders
import torch.functional as f
from torch.utils.data import Dataset, TensorDataset, DataLoader, random_split

price_folder_path = '..\integration\graphapp\prices'
price_datasets = {}
for i,paths in enumerate(os.listdir(price_folder_path)):
    dataset_path = os.path.join(price_folder_path, paths)
    price_datasets[i] = pd.read_csv(dataset_path)

total_df_list = list(price_datasets.values())
combined_df = pd.concat(total_df_list, ignore_index = True )
unique_symbols = combined_df.symbol.unique()



def get_graph( time, stocks, volume, company_name ):
    
    # need to give the sorted date
    fig, ax = plt.subplots( figsize = (20,12) )
    ax.locator_params(axis = 'x' , nbins=4)
    plt.title(f" stock prices vs date ")
    ax.plot(time, stocks, label = f'{company_name}' )
    ax.legend( loc = 'best' )
    plt.ylabel('price')
    ax.xaxis.set_major_locator( mdates.YearLocator() )
    ax.xaxis.set_major_formatter( mdates.DateFormatter('%Y') )


    # ax.xaxis.set_major_formatter(
    # mdates.ConciseDateFormatter(ax.xaxis.get_major_locator()) ) 

    ax.xaxis.set_major_locator(plt.MaxNLocator(6))
    img_path1 = "..static\img" + f"{company_name}" + f"{stocks} + .png"
    plt.savefig(img_path1)

    # need to give the sorted data
    fig, ax = plt.subplots( figsize = (20, 12) )
    plt.title(f" volume vs date ")
    ax.plot(time, volume ,label = f'{company_name}',  )
    ax.legend( loc = 'best' )
    plt.ylabel('volume_size')
    ax.xaxis.set_major_locator( mdates.YearLocator() )
    ax.xaxis.set_major_formatter( mdates.DateFormatter('%Y') )
    ax.xaxis.set_major_locator(plt.MaxNLocator(6))

    img_path2 = "..integration\static\img" + f"{company_name}" + f"{volume} + .png"
    plt.savefig(img_path2)
    plt.close(fig)


def visualize_data(name, df = combined_df):

    company_df = df[ df['symbol'] == name ]
    company_df['ds']= pd.to_datetime( company_df['ds'] )

    # sorting values based on datetime
    company_df = company_df.sort_values('ds')

    # Now getting the graph for the company
    get_graph(time = company_df['ds'].tolist() , stocks = company_df['close'].tolist(), volume = company_df['volume'].tolist(), company_name = name )
    
visualize_data(name = "TAP")